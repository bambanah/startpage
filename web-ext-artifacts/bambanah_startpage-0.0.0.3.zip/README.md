# Startpage

This startpage is designed to be fully customisable.

Google authentication is used to track links that have been saved, to keep track of links on any device.
